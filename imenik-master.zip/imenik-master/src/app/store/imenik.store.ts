import {EntityStore, StoreConfig} from '@datorama/akita';
import {OsobaModel, OsobaState} from './osoba.model';
import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root',
})
@StoreConfig({ name: 'imenik', resettable: true })
export class ImenikStore extends EntityStore<OsobaState, OsobaModel>{
  constructor() {
    super();
  }
}
