import {ImenikStore} from './imenik.store';
import {ImenikQuery} from './imenik.query';
import {OsobaModel} from './osoba.model';
import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ImenikService {
  constructor(
    private imenikStore: ImenikStore,
    private imenikQuery: ImenikQuery
  ) {}

  public saveCompany(osoba: OsobaModel): void {
    console.log('usli');
    this.imenikStore.add({
      ...osoba,
      id: osoba.id
    });
  }

  public deleteImenik(): void {
    this.imenikStore.reset();
  }
  public obrisiOsobu(osoba: OsobaModel): void {
    this.imenikStore.remove(osoba.id);
  }

  public dohvatiSveOsobe(): any {
    return this.imenikQuery.getAll();
  }
}
