import {EntityState, ID} from '@datorama/akita';

export type OsobaModel = {
  id: ID,
  ime: string,
  broj: number
};

export interface OsobaState extends EntityState<OsobaModel> {}
