import {QueryEntity} from '@datorama/akita';
import {OsobaModel, OsobaState} from './osoba.model';
import {ImenikStore} from './imenik.store';
import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ImenikQuery extends QueryEntity<OsobaState, OsobaModel> {
  constructor(protected imenikStore: ImenikStore) {
    super(imenikStore);
  }
  public dohvatiSve(): any {
    return this.getAll();
  }
}
