import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from "@angular/forms";
import {ID} from "@datorama/akita";
import {ImenikService} from "../store/imenik.service";
import {OsobaModel} from "../store/osoba.model";
export interface Osoba {
  ime: string;
  broj: number;
  id: ID;
}

@Component({
  selector: 'app-imenik',
  templateUrl: './imenik.component.html',
  styleUrls: ['./imenik.component.scss']
})
export class ImenikComponent implements OnInit {
  imenikForma: FormGroup;
  lista: Osoba[] = [];
  imenik: any;
  constructor(
    private formBuilder: FormBuilder,
    private imenikServis: ImenikService
  ) {
    this.imenikForma = this.formBuilder.group({
      ime: [''],
      broj: ['']
    });
    this.lista = this.imenikServis.dohvatiSveOsobe();
  }

  ngOnInit(): void {
  }

  onSubmit(imenikForma: FormGroup): void {
    const osoba = {
      ime: imenikForma.value.ime,
      broj: imenikForma.value.broj,
      id: new Date().getTime()
    }
    this.lista.push(osoba);
    this.imenikServis.saveCompany(osoba);
    this.imenikForma.reset();
  }

  Obrisi(osoba: Osoba): void {
    this.imenikServis.obrisiOsobu(osoba);
    this.lista.splice(this.lista.indexOf(osoba), 1);
  }
}
